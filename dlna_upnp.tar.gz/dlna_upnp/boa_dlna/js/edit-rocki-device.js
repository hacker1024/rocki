function populateData(rockisInfo){
    var rocki = JSON.parse(rockisInfo);

    currentColor = rocki.color.toLowerCase();
    currentName = rocki.name.substr(6);
    currentWifi = rocki.wifi;

    //update Name
    $('[name="Devicename"]').val(currentName);

    //update Color
    $('.color-buttons-active').removeClass('color-buttons-active');
    $('#'+currentColor).addClass('color-buttons-active');
    $('.rocki-image img').attr("src", "img/ROCKI-"+currentColor+".jpg");

    updateWifisDropdown();
}

function submitChangedValues(){
    var ssid = $('[name="Username"]').val();

    // According to what was selected by the user
    // we need to remove the other input element.
    if (ssid == "-1"){ // The 'Other' option was selected: manual text input
        $('#usernameForm').remove();
    } else { // The option was selected form the dropdown menu.
        $('#ssidForm').remove();//Attribute('name');
    }

    var urlRouter = new UrlBuilder("cgi-bin/router-info.cgi");
    urlRouter.addParam("Name",  "ROCKI_" + $('[name="Devicename"]').val() );

    if ($('[name="Username"]').val() != currentWifi){
        if (wifisData.length > 0){
            urlRouter.addParam("Username",  wifisData[$('[name="Username"]').val()].essid );
        } else {
            urlRouter.addParam("Username",  $('[name="Username"]').val() );
        }
        urlRouter.addParam("Security%20Mode", $('[name="SecurityMode"]').val() );
        urlRouter.addParam("Password",  $('[name="Password"]').val() );
    }

    // Send the data to ROCKI
    httpGet(urlRouter, null);
}

// On Settings Submit:
$(function() {
    $('#settingsForm').submit(function() {

        // This will be removed when the team removes the overlap in API calls
        if (currentName != $('[name="Devicename"]').val())
            currentName = $('[name="Devicename"]').val();

        rockiApi.submitName( currentName, function(){
            rockiApi.submitColor( currentColor.toUpperCase(), function(){
                submitChangedValues();
            });
        });

        $('#settingsForm').hide();
        $("#siteTitle").text('Values has been saved!');
        $('#statusMessage').show();

        //update the forward link.
        $("#forwardBtn").attr("href", root_setup_url+"?name="+currentName+"&color="+currentColor);

        return false; // so we can show a message to the user.
    });
});

// When the page is completly loaded:
$(document).ready(function(){

    $("#ssidForm").hide();
    $("#securityForm").hide();
    $("#wiFiPassword").hide();

    var url = $.urlParam("exit");
    if (url != null){
        setup_url = url;
        $("#cancelButton").show();
        $("#cancelButton").on( 'click', function(){ window.location.replace(setup_url); });
    }

    $(".color-buttons").on( 'click', updateColor );
    wifisInspected.watch('status', function(){
        updateWifisDropdown();
    });
    var urlRocki = new UrlBuilderFullPath(document.domain, ":8888/get_info");
    httpGet(urlRocki, populateData);

    if (wifiFromJson)
        getSSIDValues(populateSSIDDropdownFromJSON);
    else
        getSSIDValues(populateSSIDDropdown);

    $('#ssidForm input').on("keypress keyup keydown", checkWiFi);
    $('[name="Password"]').on("keypress keyup keydown", checkWiFi);
});
