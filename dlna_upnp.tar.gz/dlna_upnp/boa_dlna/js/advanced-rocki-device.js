function populateWifi(rockisInfo){
    var rocki = JSON.parse(rockisInfo);

    currentColor = rocki.color.toLowerCase();
    currentName = rocki.name.substr(6);
    currentWifi = rocki.wifi;

    updateWifisDropdown();
    removeSSIDOption();
    $('#submitButton').prop('disabled',true);
}

function submitWifiValues(){
    var urlRouter = new UrlBuilder("cgi-bin/router-info.cgi");
    if ($('[name="Username"]').val() != currentWifi){
        if ($('[name="Username"]').val() == "-1"){ // The 'Other' option was selected: manual text input
            $('#usernameForm').remove();
            urlRouter.addParam("Username",  $('[name="Username"]').val() );
        } else { // The option was selected form the dropdown menu.
            $('#ssidForm').remove();//Attribute('name');
            if (wifisData.length > 0 && wifisData[$('[name="Username"]').val()] != undefined){
                urlRouter.addParam("Username",  wifisData[$('[name="Username"]').val()].essid );
            } else {
                urlRouter.addParam("Username",  $('[name="Username"]').val() );
            }
        }
        urlRouter.addParam("Password",  $('[name="Password"]').val() );
        if ($('[name="Password"]').val() != "")
            urlRouter.addParam("Security%20Mode", $('[name="SecurityMode"]').val() );
        else
            urlRouter.addParam("Security%20Mode", "No Encryption" );
    }
    // Send the data to ROCKI
    httpGet(urlRouter, null);
}

function showUpdateMessage(message){
    $('#settingsForm').hide();
    $('#uploadFirmware').hide();
    $('.back').hide();

    $("#siteTitle").text('Values has been saved!');
    $('#statusMessage').show();
    $("#message").text(message);
    //update the forward link.
    $("#forwardBtn").attr("href", root_setup_url+"?name=ROCKI_"+currentName+"&color="+currentColor);
}

// On Settings Submit:
$(function() {
    $('#settingsForm').submit(function() {
        submitWifiValues();
        showUpdateMessage("Your WiFi settings has been successfully changed.");
        return false; // so we can show a message to the user.
    });
});

$(function() {
    $('#submitFirmwareButton').submit(function() {
        return true;
    });
});

function checkWifiWhenInAdvancedPage(){
    if (wifiFromJson){
        if (wifisData.length > 0 &&
            $('[name="Username"]').val() >= 0 &&
            currentWifi == wifisData[$('[name="Username"]').val()].essid ) {

            removeSSIDOption();
            $('#submitButton').prop('disabled', true);
        } else {
            $('#submitButton').prop('disabled', checkWiFi());
        }
    } else {
        if ( currentWifi == $('[name="Username"]').val() ) {
            removeSSIDOption();
            $('#submitButton').prop('disabled', true);
        } else {
            $('#submitButton').prop('disabled', checkWiFi());
        }
    }
}

$(document).ready(function(){
    $("#backButton").on("click", function(){ history.go(-1); } );
    $('#ssidForm input').on("keypress keyup keydown", checkWiFi);
    $('[name="Password"]').on("keypress keyup keydown", checkWiFi);

    wifisInspected.watch('status', function(){
        updateWifisDropdown();
    });
    var urlRocki = new UrlBuilderFullPath(document.domain, ":8888/get_info");
    httpGet(urlRocki, populateWifi);

    if (wifiFromJson)
        getSSIDValues(populateSSIDDropdownFromJSON);
    else
        getSSIDValues(populateSSIDDropdown);

    $('.btn-file :file').on('fileselect', function(event, numFiles, label) {

        var input = $(this).parents('.input-group').find(':text'),
            log = numFiles > 1 ? numFiles + ' files selected' : label;
        if( input.length ) {
            input.val(log);
        } else {
            if( log ) alert(log);
        }
    });

    $("#hotSpotModeButton").on("click", function(){
        rockiApi.hotSpotMode();
        showUpdateMessage("Your ROCKI is now in HOTSPOT mode! Please remember to change the wireless settings in order to reconnect the client to the ROCKI device.");
    });

    $("#factoryReset").on("click", function(){
        rockiApi.factoryReset();
        showUpdateMessage("Your ROCKI has been Factory reset! Please remember to change the wireless settings in order to reconnect the client to the ROCKI device.");
    });

});

$(document).on('change', '.btn-file :file', function() {
  var input = $(this),
      numFiles = input.get(0).files ? input.get(0).files.length : 1,
      label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
  input.trigger('fileselect', [numFiles, label]);
});
