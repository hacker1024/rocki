var onAirSwitchWifiSupported = false;

// ==============================================
// ============= SETTINGS LOGIC =================
// ==============================================

/**
 * Given an input selector will check if it has a value.
 *
 * @param selector
 *          css selector for jquery to get the inputs value and check it.
 */
function hasValue( selector ){
    return !( $(selector).val() == null || $(selector).val() == undefined || $(selector).val() == "" );
}

/**
 * Used to check if the form is valid to submition.
 */
function validateForm(){
    var nameEmpty = $('[name="Devicename"]').val() == "";
    var d = true;
    if (!nameEmpty){
        var wifi = validateWifiInput();
        if (!wifi){
            d = false;
        }
    }
    $('#submitButton').prop('disabled', d);
}

function onAirConnectToWifi( callbackSuccess, callbackError ){
    var urlOnAir = new UrlBuilderFullPath("localhost:9881/backend", "/wifi_switch_back");
    urlOnAir.addParam("ssid",  wifiToConnect.ssid);
    urlOnAir.addParam("password", wifiToConnect.password);
    httpGet(urlOnAir, callbackSuccess, callbackError);
}

//On Settings Submit:
$(function() {
    $("#step5").show();
    $(".wizard-container").show();
    $('#settingsForm').submit(function() {

        // This will be removed when the team removes the overlap in API calls
        currentName = $('[name="Devicename"]').val();

        rockiApi.submitName( currentName, function(){
            rockiApi.submitColor( currentColor.toUpperCase(), function(){
                rockiApi.submitAllValues( null, null );
            });
        });

        $('#settingsForm').hide();
        $('#statusMessage').show();

        //update the forward link.
        var forwardURL = setup_url + "?step=final&name=ROCKI_"+currentName+"&color="+currentColor;
        $("#forwardBtn").attr("href", forwardURL);
        $("#forwardBtn").attr("disabled", true);

        if (onAirSwitchWifiSupported){
            waitForWiFiToReconnect(onAirConnectToWifi);
        } else {
            waitForWiFiToReconnect(null);
        }

        return false; // so we can show a message to the user.
    });
});

function checkIfOnAirSwitchWifiIsSupported(){
    var urlRocki = new UrlBuilderFullPath("localhost:9881/backend", "/wifi_switching_supported");
    httpGet(urlRocki, function(result){
            if (result == "true"){ onAirSwitchWifiSupported = true; }
        }, null);
}

// When the page is completly loaded:
$(document).ready(function(){

    var url = $.urlParam("exit");
    if (url != null){
        setup_url = url;
        $("#cancelButton").show();
        $("#cancelButton").on( 'click', function(){
            var urlOnAir = new UrlBuilderFullPath("localhost:9881/backend", "/wifi_switch_back");
            httpGet(urlOnAir, null, null);
            if (setup_url.indexOf("localhost:9881") == 0)
                window.location.replace(setup_url);
        });
    }

    checkIfOnAirSwitchWifiIsSupported();

    $("#setupAnotherRocki").attr("href", setup_url);

    // populate the SSID dropdown
    if (wifiFromJson)
        getSSIDValues(populateSSIDDropdownFromJSON);
    else
        getSSIDValues(populateSSIDDropdown);
    removeSSIDOption();

    if($('[name="Username"]').val() == -1){
        addSSIDOption();
    }

    //clearing possibly browser stored values
    $('[name="Password"]').val("");

    $('#submitButton').prop('disabled', true);
    $(".color-buttons").on( 'click', updateColor );
    $("#settingsForm").change(validateForm);
    $("#settingsForm").on("keypress keyup keydown",validateForm);
});
