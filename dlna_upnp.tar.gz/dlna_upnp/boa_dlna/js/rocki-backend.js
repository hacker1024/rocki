// ==============================================
// ================= VARIABLES ==================
// ==============================================

// ROCKI's base url
var base_url = "http://" + location.host + "/";

// ROCKI's setup url
var setup_url = "http://www.myrocki.com/setup/connect-new-ROCKI.html";
var root_setup_url = "http://www.myrocki.com/setup/index.html";

// Rocki Api Calls object.
var rockiApi = new Object();

var currentColor = "black";
var currentName = "";
var currentWifi = "";
var wifisData = [];
// variable watched to trigger the wifi population.
var wifisInspected = { status: false };
var wifiToConnect = { ssid: "", password: "" };
var wifiFromJson = true;

// ========= Helper methods =====================

$.urlParam = function(name) {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [, ""])[1].replace(/\+/g, '%20')) || null;
};

// ==============================================
// ============= ROCKI API CALLS ================
// ==============================================

/**
 * This will submit the new Name to ROCKI.
 *
 * @param name
 *          new name given by the user.
 */
rockiApi.submitName = function ( name, callback ){
    // Submit name to cgi-bin/rocki.cgi
    var urlRocki = new UrlBuilder("cgi-bin/rocki.cgi");
    urlRocki.addParam("Name", "ROCKI_" + name );
    httpGet(urlRocki, callback);
}

/**
 * This will set the ROKCIs Color.
 *
 * @param color
 *          ROCKIs color.
 */
rockiApi.submitColor = function ( color, callback ){
    // Submit name to cgi-bin/rocki.cgi
    var urlRocki = new UrlBuilder("cgi-bin/rocki.cgi");
    urlRocki.addParam("Color", color );
    httpGet(urlRocki, callback);
}

/**
 * This will submit the wireless settings to ROCKI.
 *
 */
rockiApi.submitAllValues = function(callbackSuccess, callbackError){
    var ssid = $('[name="Username"]').val();

    var urlRouter = new UrlBuilder("cgi-bin/router-info.cgi");
    urlRouter.addParam("Name",  "ROCKI_" + $('[name="Devicename"]').val() );

    // According to what was selected by the user
    // we need to remove the other input element.
    if (ssid == "-1"){ // The 'Other' option was selected: manual text input
        $('#usernameForm').remove();
        wifiToConnect.ssid = $('[name="Username"]').val();
        urlRouter.addParam("Username",  wifiToConnect.ssid );
    } else { // The option was selected form the dropdown menu.
        $('#ssidForm').remove();//Attribute('name');
        if (wifisData.length > 0 && wifisData[$('[name="Username"]').val()] != undefined){
            wifiToConnect.ssid = wifisData[$('[name="Username"]').val()].essid;
        } else {
            wifiToConnect.ssid = $('[name="Username"]').val();
        }
        urlRouter.addParam("Username",  wifiToConnect.ssid );
    }
    wifiToConnect.password = $('[name="Password"]').val();
    urlRouter.addParam("Password",  wifiToConnect.password);
    if ($('[name="Password"]').val() != "")
        urlRouter.addParam("Security%20Mode", $('[name="SecurityMode"]').val() );
    else
        urlRouter.addParam("Security%20Mode", "No Encryption" );
    urlRouter.addParam("apUsername", "");
    urlRouter.addParam("apPassword", "");
    urlRouter.addParam("devdefault", "no");
    urlRouter.addParam("appautoupdate", "yes");

    // Send the data to ROCKI
    httpGet(urlRouter, callbackSuccess, callbackError);
}

/**
 * Factory reset will revert ROCKI back to stock firmware,
 * and will eventually reboot into hotspot mode.
 * In order to factory reset, the firmware flash procedure will be started,
 * which will flash the original firmware. (takes about 1 minute)
 */
rockiApi.factoryReset = function(){
    var urlRocki = new UrlBuilder("cgi-bin/rocki.cgi");
    urlRocki.addParam("FactoryReset", "true");
    httpGet(urlRocki);
}

/**
 * Rocki will directly reboot in hotspot mode. (​takes about 30 seconds)
 */
rockiApi.hotSpotMode = function(){
    var urlRocki = new UrlBuilder("cgi-bin/rocki.cgi");
    urlRocki.addParam("APMode", "on");
    httpGet(urlRocki);
}

/**
 * Rocki will directly reboot and disconnect from the client application.
 * ​(​takes about 30 seconds)
 */
rockiApi.reboot = function (){
    var urlRocki = new UrlBuilder("cgi-bin/rocki.cgi");
    urlRocki.addParam("Reboot", "true");
    httpGet(urlRocki);
}


// ==============

/**
 * This will update the ROCKIs color on the FE.
 */
function updateColor(){
    $("#"+currentColor).removeClass('color-buttons-active');
    $(this).addClass('color-buttons-active');
    currentColor = $(this).attr('id');
    $('.rocki-image img').attr("src", "img/ROCKI-"+currentColor+".jpg");
}

/**
 * This will show or hide manual WiFi input
 * and will show the Password input field
 */
function showOptions(){
    removeSSIDOption();
    $("#wiFiPassword").hide();

    if($('[name="Username"]').val() == -1){
        $('#ssidName').val("");
        addSSIDOption();
        return false;
    }
    else {
        if (wifiFromJson){
            if (wifisData.length != 0){
                if (wifisData[$('[name="Username"]').val()].enctype == "OPEN"){
                    $("#wiFiPassword").hide();
                    $('[name="SecurityMode"]').val("No Encryption");
                } else {
                    $("#wiFiPassword").show();
                    if (wifisData[$('[name="Username"]').val()].enctype == "WPA" ||
                        wifisData[$('[name="Username"]').val()].enctype == "WPA2")
                        $('[name="SecurityMode"]').val("WPA/WPA2");
                    else
                        $('[name="SecurityMode"]').val(wifisData[$('[name="Username"]').val()].enctype);
                }
            }
        } else {
            removeSSIDOption();
        }
    }

    if (currentWifi == "" ||
        ($('[name="Username"]').val() != "" && $('[name="Username"]').val() != currentWifi)){
        if (wifiFromJson){
            if (wifisData.length > 0 && wifisData[$('[name="Username"]').val()].enctype != "OPEN"){
                $("#wiFiPassword").show();
                $('[name="Password"]').val("");
            }
        } else {
            $("#wiFiPassword").show();
            $('[name="Password"]').val("");
        }
    } else {
        $("#wiFiPassword").hide();
    }
}

/**
 * This will add the ssid text input.
 */
function addSSIDOption(){
    $("#ssidForm").show();
    $("#securityForm").show();
    $("#wiFiPassword").show();
}

/**
 * This will remove the ssid text input.
 */
function removeSSIDOption(){
    $("#ssidForm").hide();
    $("#securityForm").hide();
    $("#wiFiPassword").hide();
    $('[name="Password"]').val("");
}

/**
 * populate the SSID dropdown with the returned values.
 *
 * @param ssids:
 *      new line ( \n ) separated ssids.
 */
function populateSSIDDropdown(ssids){

    if ( ssids != undefined && ssids != null && ssids != "" ){
        var array = ssids.split("\n");

        var insertedElement = false;
        for (var element = array.length - 1; element >= 0; element--){
            var duplicated = false;
            for (i = element - 1; i >= 0 && !duplicated; i--){
                if (array[element] == array[i]){
                    duplicated = true;
                }
            }
            if (!duplicated &&
                ! (array[element] == null || array[element] == undefined || array[element].match(/^\s*$/) )){
                var insertedElement = true;
                var o = new Option('option text', array[element] );
                o.innerHTML = array[element];
                $('[name=Username] option:first').after(o);
            }
        }

        if ( insertedElement ){
            removeSSIDOption();
        }
        if (wifisInspected != undefined){
            wifisInspected.status = true;
        }
    }
}

/**
 * populate the SSID dropdown with the returned values.
 *
 * @param ssids:
 *      Json formatted ssids.
 */
function populateSSIDDropdownFromJSON(ssids){
    var wifis;
    try {
        wifis = $.parseJSON(ssids);
    } catch (e) {
        // if the JSON received was not properly built, then we catch the error
        // and fallback to the old wifi controller logic.
        console.log("Error when parson JSON from wifiscan -> " + e);
        wifiFromJson = false;
        getSSIDValues(populateSSIDDropdown);
        return;
    }
    //var wifis = ssids;
    wifisData = wifis;
    var insertedElement = false;
    for (var element = wifis.length - 1; element >= 0; element--){
        $('[name=Username] option:first').after(
            $('<option>', {
                value: element,
                text : wifis[element].essid
            })
        );
    }
    // in case no element was inserted, then we need to show the manual SSID option.
    // otherwise hide it.
    if ( insertedElement ){
        removeSSIDOption();
    }
    if (wifisInspected != undefined){
        wifisInspected.status = true;
    }
    return false;
}

/**
 * gets the SSID available values from ROCKI.
 *
 * @param callback
 *      function(params) where params is the answer from ROCKI
 */
function getSSIDValues(callback){
    var urlssid;
    var date = new Date();
    var param = date.getTime();
    if (wifiFromJson){
        urlssid = new UrlBuilder("cgi-bin/rocki.cgi?ShellCMD=./wifiscan&no_cache="+param);
    } else {
        urlssid = new UrlBuilder("wifi_scan_tab_html.info?no_cache="+param);
    }
    //urlssid = new UrlBuilderFullPath("localhost:8880/", "wifis.php");
    httpGet(urlssid, callback);
}

function validateWifiInput(){
    var d = false;
    if ($('[name="Username"]').val() != currentWifi){
        if ($('[name="Username"]').val() == null){
            d = true;
        } else {
            if ($('[name="Username"]').val() != "-1"){
                if ($('[name="Password"]').val() == "" && $('[name="SecurityMode"]').val() != "No Encryption")
                    d = true;
            } else {
                if ( $("#ssidName").val() == "")
                    d = true;

                if ( $('[name="SecurityMode"]').val() == "No Encryption"){
                    $("#wiFiPassword").hide();
                    $('[name="Password"]').val("");
                } else {
                    addSSIDOption();
                    if ($('[name="Password"]').val() == "")
                        d = true;
                }
            }
        }
    }
    return d;
}

function checkWiFi(){
    $('#submitButton').prop('disabled', validateWifiInput());
}

function updateWifisDropdown (){
    if (wifiFromJson){
        var found = false;
        var wifiIndex = -1;
        for (var i = 0; i < wifisData.length && !found; i++){
            if (wifisData[i].essid == currentWifi){
                found = true;
                wifiIndex = i;
            }
        }

        if ( wifiIndex > -1 && !($("#usernameForm option[value='" + wifiIndex + "']").length > 0) ){
            $('[name=Username] option:first').after(
                $('<option>', {
                    value: wifiIndex,
                    text : wifisData[wifiIndex].essid
                })
            );
        }
        $("#usernameForm option[value='" + currentWifi + "']").remove();
        $('[name=Username]').val(wifiIndex);
    } else {
        if ( !($("#usernameForm option[value='" + currentWifi + "']").length > 0) ){
            $('[name=Username] option:first').after(
                $('<option>', {
                    value: currentWifi,
                    text : currentWifi
                })
            );
        }
        $('[name=Username]').val(currentWifi);
    }
}

function waitForWiFiToReconnect(){
	
	var lastAP_SSID = $('[name="Username"]').val();
	var lastAP_PW = $('[name="Password"]').val();
    //activate server to connect to ROCKI.
    var urlRocki = new UrlBuilderFullPath("localhost:9881/backend", "/wifi_switch_back?ssid=" + lastAP_SSID + "&password=" + lastAP_PW);
    httpGet(urlRocki);
    
    $("#alertMessage").hide();
    var wifiFound = false;
    var wifiInterval = setInterval(function() {
        if (!wifiFound){
            var urlRocki = new UrlBuilderFullPath("ipv4.onairplayer.com/", "rocki/find_devices");
            httpGet(urlRocki, function( devices ){
                //WiFi is back on.
                wifiFound = true;
                $("#forwardBtn").attr("disabled", false);
                // foward to setup page.
                var forwardURL = setup_url + "?step=final&name=ROCKI_"+currentName+"&color="+currentColor;
                window.location.replace(forwardURL);
            });
        }
    }, 1000);
    var wifiTimeout = window.setTimeout(function() {
        if (!wifiFound){
            $("#wifiStatus").text("Please, make sure this device connects to your home network again.");
        }
    }, 20000);

    // wrong Password Mechanism.
    var reboot = false;
    var wrongPasswordInterval = setInterval(function(){
        // no need to ping specifically to :8888/get_info as long as
        // 192.168.0.1 responds we are still connected.
        var urlRocki = new UrlBuilderFullPath(document.domain, "");
        httpGet(urlRocki, function success(){
            //we are still connected to ROCKI
            reboot = false;
            console.log("reboot FALSE");
        }, function error(){
            reboot = true;
            // Clear wrong password logic
            window.clearTimeout(wrongPasswordTimeout);
            window.clearInterval(wrongPasswordInterval);
            console.log("reboot TRUE");
            if (callback != null && typeof (callback) == 'function')
                callback();
        });
    }, 1000);
    var wrongPasswordTimeout = window.setTimeout(function(){
        if (!reboot){
            $('#settingsForm').show();
            $('#statusMessage').hide();
            $("#alertMessage").show();
            $('[name="Password"]').val("");
            window.clearInterval(wrongPasswordInterval);
            window.clearInterval(wifiInterval);
            window.clearTimeout(wifiTimeout);
        }
    }, 8000);
}

/*
 * object.watch polyfill
 *
 * 2012-04-03
 *
 * By Eli Grey, http://eligrey.com
 * Public Domain.
 * NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.
 */

// object.watch
if (!Object.prototype.watch) {
	Object.defineProperty(Object.prototype, "watch", {
		  enumerable: false
		, configurable: true
		, writable: false
		, value: function (prop, handler) {
			var
			  oldval = this[prop]
			, newval = oldval
			, getter = function () {
				return newval;
			}
			, setter = function (val) {
				oldval = newval;
				return newval = handler.call(this, prop, oldval, val);
			}
			;

			if (delete this[prop]) { // can't watch constants
				Object.defineProperty(this, prop, {
					  get: getter
					, set: setter
					, enumerable: true
					, configurable: true
				});
			}
		}
	});
}

// object.unwatch
if (!Object.prototype.unwatch) {
	Object.defineProperty(Object.prototype, "unwatch", {
		  enumerable: false
		, configurable: true
		, writable: false
		, value: function (prop) {
			var val = this[prop];
			delete this[prop]; // remove accessors
			this[prop] = val;
		}
	});
}
